#include "App.h"
#include "Rect.h"
#include <vector>

using namespace std;
Rect* r = new Rect(0.25, 0.25, 0.55, 0.55);
Rect* r1 = new Rect(-0.75, 0.8, 0.25, 0.8);
Rect* r2 = new Rect(-0.0, -0.8, 0.25, 0.25);
vector<Rect*> holdr;


App::App(const char* label, int x, int y, int w, int h): GlutApp(label, x, y, w, h) {
    // Initialize state variables
    mx = 0.0;
    my = 0.0;
    holdr.push_back(r);
    holdr.push_back(r1);
    holdr.push_back(r2);
}

void App::draw() {

    // Clear the screen
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    // Set background color to black
    glClearColor(0.0, 0.0, 0.0, 1.0);
    
    // Set up the transformations stack
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    
    // Draw a rectangle
    
    for (int i = 0; i < holdr.size(); i++) {
        holdr[i]->draw();
    }
    
    // We have been drawing everything to the back buffer
    // Swap the buffers to see the result of what we drew
    glFlush();
    glutSwapBuffers();
}

void App::mouseDown(float x, float y){
    // Update app state
    mx = x;
    my = y;
    
    //Rectangle Click Code
    for (int i = 0; i < holdr.size(); i++) {
        if (holdr[i]->contains(mx, my)) {
            holdr[i]->setRed(1);
            holdr[i]->setGreen(0.7);
            holdr[i]->setBlue(0.2);
        } else {
            holdr[i]->setRed(1);
            holdr[i]->setGreen(1);
            holdr[i]->setBlue(1);
        }
    }
   
    // Redraw the scene
    redraw();
}

void App::mouseDrag(float x, float y){
    // Update app state
    mx = x;
    my = y;
    
    // Redraw the scene
    redraw();
}

void App::keyPress(unsigned char key) {
    if (key == 27){
        // Exit the app when Esc key is pressed
        exit(0);
    }
}


