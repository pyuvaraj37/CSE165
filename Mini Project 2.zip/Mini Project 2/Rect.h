#ifndef Rect_h
#define Rect_h

#include "GlutApp.h"

class Rect
{
	private:
    
		float x, y, w, h, r, g, b;

	public:

		Rect(float a1, float a2, float a3, float a4) {

			x = a1;
			y = a2;
			w = a3;
			h = a4;
            
            r = 1;
            g = 1;
            b = 1;
            
		}
    
    
        float getRed() {
            return r;
        }
        float getBlue() {
            return b;
        }
        float getGreen() {
            return g;
        }
        void setRed(float a) {
            r = a;
        }
        void setBlue(float a) {
            b = a;
        }
        void setGreen(float a) {
            g = a;
        }

        float getWidth() {
            return w;
        }
    
        float getHeight() {
            return h;
        }
    
        float getX() {
            return x;
        }
    
        float getY() {
            return h;
        }
    
        void setWidth(float a) {
            w = a;
        }
    
        void setHeight(float a) {
            h = a;
        }
    
        void setX(float a) {
            x = a;
        }
        void setY(float a) {
            y = a;
        }
        bool contains(float a, float b) {

            if (x <= a && x + w >= a && y - h <= b && y >= b) {
                return true;
            } else {
                return false;
            }

        }
    
        void draw()
        {
            glColor3f(r, g, b);
            glBegin(GL_POLYGON);
            glVertex2f(x,y);
            glVertex2f(x + w, y);
            glVertex2f(x + w,y - h);
            glVertex2f(x, y - h);
            glEnd();
        }

};

#endif
