//
//  AI.h
//  glutapp
//
//  Created by Prithviraj Yuvaraj on 10/25/18.
//  Copyright © 2018 Angelo Kyrilov. All rights reserved.
//

#ifndef AI_h
#define AI_h
#include "Rect.h"
#include "tictac.h"
#include <vector>

class AI {
public:
    tictac* t;
    int index;
    vector<Rect*> b;
    bool sec = true;
    vector<int> threats;
    int lastMove; 
    
    AI(tictac* a) {
        
        t = a;
        b = t->board;
        
    }
    
    int play() {
        
        int i;
        
        //AI check if it has 2 in a row
        i = myThreat();
        if(i != -1) {
            if(t->turnKeeper()) {
                b[i]->setRed();
                return i;
            } else {
                b[i]->setBlue();
                return i;
            }
        }
        //AI checks if other player has 2 in a row
        i = findAThreat();
        if(i != -1) {
            if(t->turnKeeper()) {
                b[i]->setRed();
                return i;
            } else {
                b[i]->setBlue();
                return i;
            }
        }
        //AI checks if it chose a spot that causes 2 win conditions next turn
        i = findFork();
        if (i != -1) {
            if(t->turnKeeper()) {
                b[i]->setRed();
                
                return i;
            } else {
                b[i]->setBlue();
                
                return i;
            }
        }
        //AI takes the center
        if (!(b[4]->ifSet())) {
            if(t->turnKeeper()) {
                b[4]->setRed();
               
                return 4;
            } else {
                b[4]->setBlue();
                
                return 4;
            }
        }
        //If the other player takes a corner, AI will take the opposite
        switch (lastMove) {
            case 0: {
                if (!b[8]->ifSet()) {
                    if(t->turnKeeper()) {
                        b[8]->setRed();
                        
                        return 8;
                    } else {
                        b[8]->setBlue();
                        
                        return 8;
                    }
                }
                break;
            }
            case 2: {
                if (!b[6]->ifSet()) {
                    if(t->turnKeeper()) {
                        b[6]->setRed();
                        
                        return 6;
                    } else {
                        b[6]->setBlue();
                        
                        return 6;
                    }
                }
                break;
            }
            case 6: {
                if (!b[2]->ifSet()) {
                    if(t->turnKeeper()) {
                        b[2]->setRed();
                       
                        return 2;
                    } else {
                        b[2]->setBlue();
                        
                        return 2;
                    }
                }
                break;
            }
            case 8: {
                if (!b[0]->ifSet()) {
                    if(t->turnKeeper()) {
                        b[0]->setRed();
                        
                        return 0;
                    } else {
                        b[0]->setBlue();
                        
                        return 0;
                    }
                }
                break;
            }
                
        }
        
        //AI places at next availible spot
        for (i = 0; i < b.size(); i++) {
            
            if (!b[i]->ifSet()) {
                if(t->turnKeeper()) {
                    b[i]->setRed();
                    
                    return i;
                } else {
                    b[i]->setBlue();
                   
                    return 0;
                }
            }
            
        }
        
        
 
            
    }
    
    //Looks for 2 in a row
    int myThreat() {
        
        if(t->turnKeeper()) {
            
            for (int i = 0; i < b.size(); i++) {
                
                threat2Blue(i);
                
            }
            
        } else {
            
            for (int i = 0; i < b.size(); i++) {
                
                threat2Red(i);
                
            }
            
        }
        
        if (threats.size() == 0) {
            return -1;
        }
        
        int index = threats[threats.size() - 1];
        threats.pop_back();
        return index;
    }

    
    
    //Looks for 2 X's in a row
    void threat2Red(int i) {
        
        if(b[i]->checkBlue()) {
            
            if(i == 4) {
                
                if (b[0]->checkBlue() && !(b[8]->ifSet())) {
                    threats.push_back(8);
                }
                if (b[8]->checkBlue() && !(b[0]->ifSet())) {
                    threats.push_back(0);
                }
                
                if (b[1]->checkBlue() && !(b[7]->ifSet())) {
                    threats.push_back(7);
                }
                
                if (b[7]->checkBlue() && !(b[1]->ifSet())) {
                    threats.push_back(1);
                }
                
                if (b[2]->checkBlue() && !(b[6]->ifSet())) {
                    threats.push_back(6);
                }
                
                if (b[3]->checkBlue() && !(b[5]->ifSet())) {
                    threats.push_back(5);
                }
            }
            
            switch (i) {
                    
                case 0: {
                    
                    if (b[1]->checkBlue() && !(b[2]->ifSet())) {
                        threats.push_back(2);
                    }
                    if (b[3]->checkBlue() && !(b[6]->ifSet())) {
                        threats.push_back(6);
                    }
                    
                    if (b[2]->checkBlue() && !(b[1]->ifSet())) {
                        threats.push_back(1);
                    }
                    if (b[6]->checkBlue() && !(b[3]->ifSet())) {
                        threats.push_back(3);
                    }
                    break;
                }
                case 2: {
                    
                    if (b[1]->checkBlue() && !(b[0]->ifSet())) {
                        threats.push_back(0);
                    }
                    if (b[5]->checkBlue() && !(b[8]->ifSet())) {
                        threats.push_back(8);
                    }
                    
                    if (b[0]->checkBlue() && !(b[1]->ifSet())) {
                        threats.push_back(1);
                    }
                    
                    if (b[8]->checkBlue() && !(b[5]->ifSet())) {
                        threats.push_back(5);
                    }
                    
                    break;
                }
                case 6: {
                    
                    if (b[3]->checkBlue() && !(b[0]->ifSet())) {
                        threats.push_back(0);
                    }
                    if (b[7]->checkBlue() && !(b[8]->ifSet())) {
                        threats.push_back(8);
                    }
                    
                    if (b[0]->checkBlue() && !(b[3]->ifSet())) {
                        threats.push_back(3);
                    }
                    if (b[8]->checkBlue() && !(b[7]->ifSet())) {
                        threats.push_back(7);
                    }
                    
                    break;
                }
                case 8: {
                    
                    if (b[5]->checkBlue() && !(b[2]->ifSet())) {
                        threats.push_back(2);
                    }
                    if (b[7]->checkBlue() && !(b[6]->ifSet())) {
                        threats.push_back(6);
                    }
                    
                    if (b[2]->checkBlue() && !(b[5]->ifSet())) {
                        threats.push_back(5);
                    }
                    if (b[6]->checkBlue() && !(b[7]->ifSet())) {
                        threats.push_back(7);
                    }
                    break;
                }
                    
            }
            
            
        }
        
    }
    
    //Looks for 2 O's in a row
    void threat2Blue(int i) {
        
        if(b[i]->checkRed()) {
            
            
            if(i == 4) {
                
                if (b[0]->checkRed() && !(b[8]->ifSet())) {
                    threats.push_back(8);
                }
                if (b[8]->checkRed() && !(b[0]->ifSet())) {
                    threats.push_back(0);
                }
                
                if (b[1]->checkRed() && !(b[7]->ifSet())) {
                    threats.push_back(7);
                }
                
                if (b[7]->checkRed() && !(b[1]->ifSet())) {
                    threats.push_back(1);
                }
                
                if (b[2]->checkRed() && !(b[6]->ifSet())) {
                    threats.push_back(6);
                }
                
                if (b[3]->checkRed() && !(b[5]->ifSet())) {
                    threats.push_back(5);
                }
            }
            
            switch (i) {
                    
                case 0: {
                    
                    if (b[1]->checkRed() && b[2]->checkRed()) {
                        threats.push_back(0);
                    }
                    if (b[3]->checkRed() && !(b[6]->ifSet())) {
                        threats.push_back(6);
                    }
                    
                    if (b[2]->checkRed() && !(b[1]->ifSet())) {
                        threats.push_back(1);
                    }
                    if (b[6]->checkRed() && !(b[3]->ifSet())) {
                        threats.push_back(3);
                    }
                    
                    break;
                }
                case 2: {
                    
                    if (b[1]->checkRed() && !(b[0]->ifSet())) {
                        threats.push_back(0);
                    }
                    if (b[5]->checkRed() && !(b[8]->ifSet())) {
                        threats.push_back(8);
                    }
                    
                    if (b[0]->checkRed() && !(b[1]->ifSet())) {
                        threats.push_back(1);
                    }
                    if (b[8]->checkRed() && !(b[5]->ifSet())) {
                        threats.push_back(5);
                    }
                    
                    break;
                }
                case 6: {
                    
                    if (b[3]->checkRed() && !(b[0]->ifSet())) {
                        threats.push_back(0);
                    }
                    if (b[7]->checkRed() && !(b[8]->ifSet())) {
                        threats.push_back(8);
                    }
                    
                    if (b[0]->checkRed() && !(b[3]->ifSet())) {
                        threats.push_back(3);
                    }
                    if (b[8]->checkRed() && !(b[7]->ifSet())) {
                        threats.push_back(7);
                    }
                    
                    break;
                }
                case 8: {
                    
                    if (b[5]->checkRed() && !(b[2]->ifSet())) {
                        threats.push_back(2);
                    }
                    if (b[7]->checkRed() && !(b[6]->ifSet())) {
                        threats.push_back(6);
                    }
                    
                    if (b[2]->checkRed() && !(b[5]->ifSet())) {
                        threats.push_back(5);
                    }
                    if (b[6]->checkRed() && !(b[7]->ifSet())) {
                        threats.push_back(7);
                    }
                    
                    break;
                }
                    
            }
            
            
        }
        
    }
    
    //Check for respective threats.
    //First clears previous turns threats.
    int findAThreat() {
        
        threats.clear();
        
        if(t->turnKeeper()) {
            
            for (int i = 0; i < b.size(); i++) {
                
                threat2Red(i);
                
            }
            
        } else {
            
            for (int i = 0; i < b.size(); i++) {
                
                
                threat2Blue(i);
                
            }
            
        }
        
        if (threats.size() == 0) {
            return -1;
        }
        
        int index = threats[threats.size() - 1];
        threats.pop_back();
        return index;
        
        
    }
    
    //Threats are 2 in a row. 
    //Finds a spot that causes 2 threats.
    int findFork() {
        //NEED TO FIND 2 THREATS
        for (int i = 0; i < b.size(); i++) {
            if (!b[i]->ifSet()) {
                
                b[i]->setSet();
            
                for (int j = 0; j < b.size(); j++) {
                    if(t->turnKeeper()) {
                        threat2Red(j);
                    } else {
                        threat2Blue(j);
                    }
                }
                
                if (threats.size() == 2) {
                    
                    return i;
                }
                
                b[i]->unSet();
            }
        }
        return -1;
        
    }
    
        
};
    
    
    
    






#endif /* AI_h */
