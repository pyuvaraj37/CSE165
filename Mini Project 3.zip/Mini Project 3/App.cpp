#include "App.h"
#include "Rect.h"
#include "tictac.h"
#include <vector>
#include "menu.h"
#include "AI.h"
#include "count.h"

using namespace std;

//Initialize the menu
//Intialize the Tittac game and board inside tictac.h
//Intialize the counter
menu* m = new menu();
tictac* t = new tictac();
countin* c = new countin();

//s is the vector to hold the rects for the menu
//v is the vector to hold the rects for the board
vector<Rect*> s = m->options;
vector<Rect*> v = t->board;

App::App(const char* label, int x, int y, int w, int h): GlutApp(label, x, y, w, h) {
    // Initialize state variables
    mx = 0.0;
    my = 0.0;
    
}

void App::draw() {

    // Clear the screen
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    // Set background color to black
    glClearColor(0.0, 0.0, 0.0, 1.0);
    
    // Set up the transformations stack
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    //Test if the board is filled. To get the value ifFull();
    t->isFull();
    
    //Check if the game is won or the table is full
    if (t->checkWin() || t->ifFull()) {
        
        //Draw the winning line or if a tie: t->winType = 0; then no line
        t->winLine(t->winType);
 
    }
    //Check if the menu has been selected or not
    // if not draw the menu.
    if (!(m->ifSelected())) {
        s[0]->label(1);
        s[0]->draw();
        s[1]->label(2);
        s[1]->draw();
    }
    
    //After the menu is selected and the count down is not done:
    //Start the count down
    if(m->ifSelected() && !(c->done)) {
        c->draw();
        //wait 1 second
        usleep(1000000);
        if (c->holder == -1) {
            //if count down is done
            //wait 1 second and start the game
            usleep(1000000);
            c->start();
        }
        redraw();
    }
    
    //if the count down is done. Draw the game board
    if (c->done) {
        for (int i = 0; i < v.size(); i++) {
            v[i]->draw();
        }
    }
    
    
    

    // We have been drawing everything to the back buffer
    // Swap the buffers to see the result of what we drew
    glFlush();
    glutSwapBuffers();
}

void App::mouseDown(float x, float y){
    // Update app state
    mx = x;
    my = y;
    
    
    //Checking all the sqaures
    for (int i = 0; i < v.size(); i++) {
        //Player -> AI
        // 1 vs COM
        if (m->ifSolo()) {
            
            //Saves the first move made by the player
            if (v[i]->FirstTurn() == 0) {
                v[i]->setFirst();
            }
            
            //If the clicked spot is within a Rect
            //and that Rect is not set
            //and no one has won
            //and the count down is done
            if(v[i]->contains(mx, my) && !(v[i]->ifSet()) && !(t->checkWin()) && c->done) {
                
                
                if(t->turnKeeper()) {
                    v[i]->setRed();
                } else {
                    v[i]->setBlue();
                }
                v[i]->setSet();
                t->nextTurn();
                
                t->isFull();
                
                if (!(t->ifFull())) {
                    //AI Turn
                    AI* ultimateAI = new AI(t);
                    ultimateAI->lastMove = i;
                    int j = ultimateAI->play();
                    v[j]->setSet();
                    t->nextTurn();
                }
                
                
                
                
            }
        // 1 Vs 2
        } else {
            //If the clicked spot is within a Rect
            //and that Rect is not set
            //and no one has won
            //and the count down is done
            if(v[i]->contains(mx, my) && !(v[i]->ifSet()) && !(t->checkWin()) && !(m->ifSolo()) && c->done) {
                
                
                if(t->turnKeeper()) {
                    v[i]->setRed();
                } else {
                    v[i]->setBlue();
                }
                v[i]->setSet();
                t->nextTurn();
                
            }
        }
    }
    
    
    //Clicked spot is within menu Rect(1 vs COM)
    if (s[0]->contains(mx, my) && !(m->ifSelected())) {
        m->isSolo(true);
        m->select();
    }
    //Clicked spot is within menu Rect(1 vs 2)
    if (s[1]->contains(mx, my) && !(m->ifSelected())) {
        m->isSolo(false);
        m->select();
    }
    
    
   
    // Redraw the scene
    redraw();
}

void App::mouseDrag(float x, float y){
    // Update app state
    mx = x;
    my = y;

    
    // Redraw the scene
    redraw();
}

void App::keyPress(unsigned char key) {
    if (key == 27){
        // Exit the app when Esc key is pressed
        delete c;
        delete t;
        delete m;
        exit(0);
    }
    
    
}


