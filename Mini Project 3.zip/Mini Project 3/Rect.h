#ifndef Rect_h
#define Rect_h

#include "GlutApp.h"
#include "Math.h"

class Rect
{
	private:
    
		float x, y, w, h, r, g, b;
        bool set = false; ;
        bool blueC = false;
        bool redC = false;

	public:
    
        bool firstTurn = false;
    
		Rect(float a, float b) {

			x = a;
			y = b;
			w = 0.20;
			h = 0.20;
            
            r = 1;
            g = 1;
            b = 1;

            
		}
    
        Rect(float a, float b, float c, float d) {
            
            x = a;
            y = b;
            w = c;
            h = d;
            
            r = 1;
            g = 1;
            b = 1;
            
            
        }
    
        //Check if the Rect is X
        bool checkBlue() {
            return blueC;
        }
        //Check if the Rect is O
        bool checkRed() {
            return redC; 
        }
        //Check if the Rect is set
        bool ifSet() {
            return set;
        }
    
        //Make the Rect set
        void setSet() {
            set = true;
        }
    
        //Make the Rect a O
        void setRed() {
            r = 1;
            g = 0;
            b = 0;
            redC = true;
        }
        //Make the Rect a X
        void setBlue() {
            r = 0;
            g = 0;
            b = 1;
            blueC = true;
        }
    
        //Unset a space (Only used by AI)
        void unSet() {
            set = false;
            r = 1;
            g = 1;
            b = 1;
        }
    
        //Check if the coordinate is in the Rect
        bool contains(float a, float b) {

            if (x <= a && x + w >= a && y - h <= b && y >= b) {
                return true;
            } else {
                return false;
            }

        }
    
        //Draw a circle
        void DrawCircle(float cx, float cy, float r) {
            glBegin(GL_LINE_LOOP);
            for (int ii = 0; ii < 40; ii++)   {
                float theta = 2.0f * 3.1415926f * float(ii) / 40;
                float x = r * cosf(theta);
                float y = r * sinf(theta);
                glVertex2f(x + cx, y + cy);
            }
            glEnd();
        }
    
        //Used for menu to make the menu options
        void label(int n) {
            
            if (n == 1) {
                glColor3f(0, 0, 1);
                glBegin(GL_POLYGON);
                glVertex2f(-0.01, 0.15);
                glVertex2f(0.01, 0.15);
                glVertex2f(0.01, 0.1);
                glVertex2f(-0.01, 0.1);
                glEnd();
            }
            if (n == 2) {
                
                glColor3f(0, 0, 1);
                glBegin(GL_POLYGON);
                glVertex2f(-0.025, -0.05);
                glVertex2f(-0.005, -0.05);
                glVertex2f(-0.005, -0.1);
                glVertex2f(-0.025, -0.1);
                glEnd();
                
                glColor3f(0, 0, 1);
                glBegin(GL_POLYGON);
                glVertex2f(0.005, -0.05);
                glVertex2f(0.025, -0.05);
                
                glVertex2f(0.025, -0.1);
                glVertex2f(0.005, -0.1);
                glEnd();
                
            }
           
            
        }
    
        //Check if a Rect was clicked the first turn
        bool FirstTurn() {
            return firstTurn;
        }
    
        //Set the Rect as the first turn
        void setFirst() {
            firstTurn = true;
        }
    
    
        //Draw the tic tac board
        void draw()
        {
            glColor3f(r, g, b);
            
            
            if(!checkBlue() && !checkRed()) {
                
                glBegin(GL_POLYGON);
                glVertex2f(x,y);
                glVertex2f(x + w, y);
                glVertex2f(x + w,y - h);
                glVertex2f(x, y - h);
                
            }
            
            if (checkBlue()) {
                
                glBegin(GL_LINES);
                glVertex2f(x, y);
                glVertex2f(x + w, y - h);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(x + w, y);
                glVertex2f(x, y - h);
                
            }
            
            if (checkRed()) {
                
                DrawCircle(x + 0.1, y - 0.1, 0.1);
                
                
            }
            
            
            glEnd();
        }

};

#endif
