//
//  count.h
//  glutapp
//
//  Created by Prithviraj Yuvaraj on 10/28/18.
//  Copyright © 2018 Angelo Kyrilov. All rights reserved.
//

#ifndef count_h
#define count_h
#include "GlutApp.h"
#include "Math.h"
#include <chrono>
#include <thread>
#include <unistd.h>

struct countin {
    
public:
    
    bool done;
    int holder;
    
    countin() {
        done = false;
        holder = 3;
    }
    
    //If done is true, the tic tac game starts
    void start() {
        done = true;
    }
    
    void draw() {
        
        switch (holder) {
            //Draw a 3
            case 3: {
                
                glBegin(GL_LINES);
                glVertex2f(-0.125, 0.25);
                glVertex2f(0.125, 0.25);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(0.125, 0.25);
                glVertex2f(0.125, -0.25);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(0.125, -0.25);
                glVertex2f(-0.125, -0.25);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(-0.125, -0.25);
                glVertex2f(-0.125, -0.15);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(-0.125, -0.15);
                glVertex2f(0.025, -0.15);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(0.025, -0.15);
                glVertex2f(0.025, -0.05);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(0.025, -0.05);
                glVertex2f(-0.125, -0.05);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(-0.125, -0.05);
                glVertex2f(-0.125, 0.05);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(-0.125, 0.05);
                glVertex2f(0.025, 0.05);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(0.025, 0.05);
                glVertex2f(0.025, 0.15);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(0.025, 0.15);
                glVertex2f(-0.125, 0.15);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(-0.125, 0.15);
                glVertex2f(-0.125, 0.25);
                glEnd();
                
                break;
            }
            //Draw a 2
            case 2: {
                
                glBegin(GL_LINES);
                glVertex2f(-0.125, 0.05);
                glVertex2f(0, 0.25);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(0, 0.25);
                glVertex2f(0.125, 0);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(0.125, 0);
                glVertex2f(-0.025, -0.15);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(-0.025, -0.15);
                glVertex2f(0.125, -0.15);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(0.125, -0.15);
                glVertex2f(0.125, -0.25);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(0.125, -0.25);
                glVertex2f(-0.125, -0.25);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(-0.125, -0.25);
                glVertex2f(-0.125, -0.15);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(-0.125, -0.15);
                glVertex2f(0.0625, 0);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(0.0625, 0);
                glVertex2f(0, 0.15);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(0, 0.15);
                glVertex2f(-0.125, -0.05);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(-0.125, -0.05);
                glVertex2f(-0.125, 0.05);
                glEnd();
                
                break;
            }
            //Draw a 1
            case 1: {
                
                glBegin(GL_LINES);
                glVertex2f(-0.05, 0.25);
                glVertex2f(0.05, 0.25);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(0.05, 0.25);
                glVertex2f(0.05, -0.25);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(0.05, -0.25);
                glVertex2f(-0.05, -0.25);
                glEnd();
                
                glBegin(GL_LINES);
                glVertex2f(-0.05, -0.25);
                glVertex2f(-0.05, 0.25);
                glEnd();
                
                break;
            }
                
                
        }
        holder--; 
        
    }
    
    
    
};

#endif /* count_h */
