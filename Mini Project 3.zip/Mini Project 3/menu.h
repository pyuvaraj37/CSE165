//
//  menu.h
//  glutapp
//
//  Created by Prithviraj Yuvaraj on 10/22/18.
//  Copyright © 2018 Angelo Kyrilov. All rights reserved.
//

#ifndef menu_h
#define menu_h
#include "Rect.h"
#include <vector>

using namespace std;

struct menu {
    
public:
    
    vector<Rect*> options;
    bool selected = false;
    bool s;
    
    //Only constructor that makes the menu
    menu() {
        
        Rect* solo = new Rect(-0.3, 0.20, 0.60, 0.15);
        Rect* duo = new Rect(-0.3, 0.0, 0.60, 0.15);
        
        options.push_back(solo);
        options.push_back(duo);

    }
    
    //Sets s to true or false. Decides if 1vCOM or 1v2.
    void isSolo(bool a) {
        s = a;
    }
    //Returns if 1vCOM or 1v2.
    bool ifSolo() {
        return s;
    }
    
    //Sets the menu to selected.
    void select() {
        selected = true;
    }
    
    //Checks if the menu has been selected.
    bool ifSelected() {
        return selected;
    }
    
};



#endif /* menu_h */
