//
//  tictac.h
//  glutapp
//
//  Created by Prithviraj Yuvaraj on 10/17/18.
//  Copyright © 2018 Angelo Kyrilov. All rights reserved.
//

#ifndef tictac_h
#define tictac_h


#include "Rect.h"
#include <vector>

int t_size = 9;

using namespace std;

class tictac {
    
public:
    
    vector<Rect*> board;
    int timeKeeper = 0;
    bool p1t = true;
    bool rW = false;
    bool bW = false;
    bool fill;
    int winType = 0;
    
    //Singleplayer
    tictac() {
        
        Rect* topr = new Rect(-0.35, 0.35);
        Rect* topm = new Rect(-0.10, 0.35);
        Rect* topl = new Rect(0.15, 0.35);
        Rect* midr = new Rect(-0.35, 0.10);
        Rect* midm = new Rect(-0.10, 0.10);
        Rect* midl = new Rect(0.15, 0.10);
        Rect* botr = new Rect(-0.35, -0.15);
        Rect* botm = new Rect(-0.10, -0.15);
        Rect* botl = new Rect(0.15, -0.15);
        
        board.push_back(topr);
        board.push_back(topm);
        board.push_back(topl);
        board.push_back(midr);
        board.push_back(midm);
        board.push_back(midl);
        board.push_back(botr);
        board.push_back(botm);
        board.push_back(botl);
        
        p1t = false;
        
    }
    
    //If O wins
    bool didRwin() {
        return rW;
    }
    
    //If X wins
    bool didBwin() {
        return bW;
    }
    
    //Alternates between 1st player turns and not.
    void nextTurn() {
        p1t = !p1t; 
    }
    
    //Returns if it is 1st players turn or not.
    bool turnKeeper() {
        return p1t;
    }
    
    //Check all win condition
    //
    //Checks for all 8 win conditions
    //
    //Declares a win type
    bool checkWin() {
        
        if(board[0]->checkRed()) {
            
            if (board[1]->checkRed() && board[2]->checkRed()) {
                rW = true;
                winType = 1;
                return true;
            }
            
            if (board[3]->checkRed() && board[6]->checkRed()) {
                rW = true;
                winType = 4;
                return true;
            }
            
            if (board[4]->checkRed() && board[8]->checkRed()) {
                rW = true;
                winType = 7;
                return true;
            }
            
        }
        
        if(board[0]->checkBlue()) {
            
            if (board[1]->checkBlue() && board[2]->checkBlue()) {
                bW = true;
                winType = 1;
                return true;
            }
            
            if (board[3]->checkBlue() && board[6]->checkBlue()) {
                bW = true;
                winType = 4;
                return true;
            }
            
            if (board[4]->checkBlue() && board[8]->checkBlue()) {
                bW = true;
                winType = 7;
                return true;
            }
            
        }
        
        if(board[1]->checkRed()) {
            
            if (board[0]->checkRed() && board[2]->checkRed()) {
                rW = true;
                winType = 1;
                return true;
            }
            
            if (board[4]->checkRed() && board[7]->checkRed()) {
                rW = true;
                winType = 5;
                return true;
            }
            
        }
        
        if(board[1]->checkBlue()) {
            
            if (board[0]->checkBlue() && board[2]->checkBlue()) {
                bW = true;
                winType = 1;
                return true;
            }
            
            if (board[4]->checkBlue() && board[7]->checkBlue()) {
                bW = true;
                winType = 5;
                return true;
            }
            
        }
        
        if(board[2]->checkRed()) {
            
            if (board[0]->checkRed() && board[1]->checkRed()) {
                rW = true;
                winType = 1;
                return true;
            }
            
            if (board[5]->checkRed() && board[8]->checkRed()) {
                rW = true;
                winType = 6;
                return true;
            }
            
            if (board[4]->checkRed() && board[6]->checkRed()) {
                rW = true;
                winType = 8;
                return true;
            }
            
        }
        
        if(board[2]->checkBlue()) {
            
            if (board[0]->checkBlue() && board[1]->checkBlue()) {
                bW = true;
                winType = 1;
                return true;
            }
            
            if (board[5]->checkBlue() && board[8]->checkBlue()) {
                bW = true;
                winType = 6;
                return true;
            }
            
            if (board[4]->checkBlue() && board[6]->checkBlue()) {
                bW = true;
                winType = 8;
                return true;
            }
            
        }
        
        if(board[3]->checkRed()) {
            
            if (board[4]->checkRed() && board[5]->checkRed()) {
                rW = true;
                winType = 2;
                return true;
            }
            
        }
        
        if(board[3]->checkBlue()) {
            
            if (board[4]->checkBlue() && board[5]->checkBlue()) {
                bW = true;
                winType = 2;
                return true;
            }
        
        }
        
        if(board[6]->checkRed()) {
            
            if (board[7]->checkRed() && board[8]->checkRed()) {
                rW = true;
                winType = 3;
                return true;
            }
            
        }
        
        if(board[6]->checkBlue()) {
            
            if (board[7]->checkBlue() && board[8]->checkBlue()) {
                bW = true;
                winType = 3;
                return true;
            }
            
        }
        
        return false; 
        
    }
    
    //Finds the first open space.
    int notUsed() {
        for (int i = 0; i < t_size; i++) {
            if(!(board[i]->ifSet())) {
                return i; 
            }
        }
    }
    
    //Checks if the board is full or not.
    void isFull() {
        int j = 0;
        for (int i = 0; i < t_size; i++) {
            if(board[i]->ifSet()) {
                j++;
            }
        }
        
        if (j == t_size) {
            fill = true;
        } else {
            fill = false; 
        }
        
        
    }
    
    //Returns if the board is full or not.
    bool ifFull() {
        return fill; 
    }
    
    //Draws win lines for the respective wintype.
    //If draw win type will stay 0. So nothing happens. 
    void winLine(int i) {
        
        glColor3f(1, 1, 1);
        switch (i) {
            case 1: {
                
                glBegin(GL_LINES);
                glVertex2f(-0.5, 0.25);
                glVertex2f(0.5, 0.25);
                glEnd();
                
                break;
            }
            case 2: {
                
                glBegin(GL_LINES);
                glVertex2f(-0.5, 0);
                glVertex2f(0.5, 0);
                glEnd();
                
                break;
            }
            case 3: {
                
                glBegin(GL_LINES);
                glVertex2f(-0.5, -0.25);
                glVertex2f(0.5, -0.25);
                glEnd();
                
                break;
            }
            case 4: {
                
                glBegin(GL_LINES);
                glVertex2f(-0.25, 0.5);
                glVertex2f(-0.25, -0.5);
                glEnd();
                
                break;
            }
            case 5: {
                glBegin(GL_LINES);
                glVertex2f(0, 0.5);
                glVertex2f(0, -0.5);
                glEnd();
                break;
            }
            case 6: {
                glBegin(GL_LINES);
                glVertex2f(0.25, 0.5);
                glVertex2f(0.25, -0.5);
                glEnd();
                break;
            }
            case 7: {
                glBegin(GL_LINES);
                glVertex2f(-0.5, 0.5);
                glVertex2f(0.5, -0.5);
                glEnd();
                break;
            }
            case 8: {
                glBegin(GL_LINES);
                glVertex2f(0.5, 0.5);
                glVertex2f(-0.5, -0.5);
                glEnd();
                break;
            }
                
    
        }
    }
    
    /* ~tictac(){
            for (int i = 0; i < board.size(); i++) {
                delete board[i];
            }
            delete board;
     }
     */
   
    
};




#endif /* tictac_h */
